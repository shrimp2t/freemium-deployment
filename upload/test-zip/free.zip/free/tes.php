<?php




    $array = array(
        'string' => 'this is free version',
    );

    function get_content( ){
        // my free content here
    }
