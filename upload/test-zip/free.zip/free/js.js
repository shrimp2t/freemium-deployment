/**
 * Created by truongsa on 1/18/17.
 */


jQuery( document ).ready( function( $ ) {

    var j =  1;

    $( 'a').on( 'click', function(){

        console.log( 'click' );


        

    } );

} );